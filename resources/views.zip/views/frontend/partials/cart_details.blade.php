z`<div class="container">
    <div class="row cols-xs-space cols-sm-space cols-md-space">

        <div class="col-xl-4 mx-lg-auto">
            @include('frontend.partials.cart_summary')
        </div>
    </div>
</div>

<script type="text/javascript">
    cartQuantityInitialize();
</script>
